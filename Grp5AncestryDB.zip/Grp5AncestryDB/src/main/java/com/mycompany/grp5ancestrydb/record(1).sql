-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2016 at 09:55 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `record`
--

-- --------------------------------------------------------

--
-- Table structure for table `childof`
--

CREATE TABLE `childof` (
  `childId` int(11) NOT NULL,
  `parrentId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `childof`
--

INSERT INTO `childof` (`childId`, `parrentId`) VALUES
(4, 5),
(4, 6),
(5, 7),
(5, 8),
(6, 9),
(6, 10),
(11, 4),
(12, 4),
(13, 4),
(14, 4),
(15, 11),
(16, 11),
(17, 11),
(18, 11);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `Id` int(11) NOT NULL,
  `firstName` varchar(40) NOT NULL,
  `secondName` varchar(40) NOT NULL,
  `birthday` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`Id`, `firstName`, `secondName`, `birthday`) VALUES
(4, 'Bob', 'Smith', 'Jan 10'),
(5, 'Charlie', 'Smith', 'June 18'),
(6, 'Sharon', 'Smith', 'August 13'),
(7, 'Wayne ', 'Smith', 'April 30'),
(8, 'Elvera', 'Smith', 'May 5'),
(9, 'Jim ', 'Cooley', 'Jan 7'),
(10, 'Helen', 'Cooley', 'April 24'),
(11, 'Tina', 'Smith', 'Dec 21'),
(12, 'Ron', 'Smith', 'August 13'),
(13, 'Holly', 'Smith', 'December 23'),
(14, 'Jeff', 'Smith', 'February 3'),
(15, 'Naomi ', 'Nielson', 'September 21'),
(16, 'Jonah', 'Neilson', 'March 14'),
(17, 'Grace', 'Nielson', 'May 19'),
(18, 'Gabe', 'Neilson', 'October 7');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `childof`
--
ALTER TABLE `childof`
  ADD PRIMARY KEY (`childId`,`parrentId`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
