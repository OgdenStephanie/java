/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.grp5ancestrydb;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DB_Connection 
{
    public Connection Connection()
    {
        
            
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn =null;
            try {
               // conn = DriverManager.getConnection("jdbc:mysql://mysql43155-byrhotels.whelastic.net/website","root","YqmLLjc2Pl");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/record","root","");
            } catch (SQLException ex) {
                Logger.getLogger(DB_Connection.class.getName()).log(Level.SEVERE, null, ex);
            }
            
          
            return conn;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DB_Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        return null;
    }
}
