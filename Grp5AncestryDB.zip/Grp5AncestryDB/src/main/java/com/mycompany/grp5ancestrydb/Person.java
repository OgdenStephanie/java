/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.grp5ancestrydb;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Stephanie
 */
public class Person {
    private String firstName, secondName , birthday;
    int id;

    public String getFirstName() {
        return firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public String getBirthday() {
        return birthday;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    
    public List<Person> getParents(int search) {
        List<Person> parents = new ArrayList<Person>();
        List<Integer> parentsId = new ArrayList<Integer>();
        
        parentsId = ChildOf.getParentsID(search);
         System.out.println("Size "+parentsId.size());
        
        
       
        
        try {
            DB_Connection dbconn = new DB_Connection();
            Connection myconnection = dbconn.Connection();
            String sqlString;
             
            for(Integer id2:parentsId)
            {
                System.out.println(id2);
            sqlString = "SELECT * from `record`.`person` Where Id = '" + id2 + "'";

           Statement myStatement = myconnection.createStatement();
            ResultSet rs = myStatement.executeQuery(sqlString);
            while (rs.next()) {
                 Person p = new Person();
                 p.setId(Integer.parseInt(rs.getString("Id")));
                p.setFirstName(rs.getString("firstName"));
                p.setSecondName(rs.getString("secondName"));
                p.setBirthday(rs.getString("birthday"));
                
                parents.add(p);
                System.out.println("pp");
            }
             myStatement.close();
                
            }
            myconnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return parents;
    }
    
    public List<Person> getChilds(int search) {
        List<Person> childs = new ArrayList<Person>();
        List<Integer> childsId = new ArrayList<Integer>();
        
        childsId = ChildOf.getChildsID(search);
        
       
        
        try {
            DB_Connection dbconn = new DB_Connection();
            Connection myconnection = dbconn.Connection();
            String sqlString;
            for(int id:childsId)
            {
            sqlString = "SELECT * from `record`.`person` Where Id = '" + id + "'";

            Statement myStatement = myconnection.createStatement();
            ResultSet rs = myStatement.executeQuery(sqlString);
            while (rs.next()) {
                 Person p = new Person();
                p.setId(Integer.parseInt(rs.getString("Id")));
                p.setFirstName(rs.getString("firstName"));
                p.setSecondName(rs.getString("secondName"));
                p.setBirthday(rs.getString("birthday"));
                
                childs.add(p);
            }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return childs;
    }
    
    public List<Person> getGrandChilds(int search) {
        List<Person> childs = new ArrayList<Person>();
        List<Person> grandChilds= new ArrayList<Person>();
        
        childs = getChilds(search);
        
        
            for(Person person:childs)
            {
              grandChilds.addAll(getChilds(person.id));
            }
         
        return grandChilds;
    }
    
    public List<Person> getGrandParrents(int search) {
        List<Person> parrents = new ArrayList<Person>();
        List<Person> grandParrents= new ArrayList<Person>();
        
        parrents = getParents(search);
        
        
            for(Person person:parrents)
            {
              grandParrents.addAll(getParents(person.id));
            }
         
        return grandParrents;
    }
    
    public List<Person> getALL() {
        List<Person> person = new ArrayList<Person>();
        
        
        
        try {
            DB_Connection dbconn = new DB_Connection();
            Connection myconnection = dbconn.Connection();
            String sqlString;
            
            sqlString = "SELECT * from `record`.`person`";

            Statement myStatement = myconnection.createStatement();
            ResultSet rs = myStatement.executeQuery(sqlString);
            while (rs.next()) {
                Person p = new Person();
                p.setId(Integer.parseInt(rs.getString("Id")));
                p.setFirstName(rs.getString("firstName"));
                p.setSecondName(rs.getString("secondName"));
                p.setBirthday(rs.getString("birthday"));
                
                person.add(p);
            }
           myStatement.close();
                myconnection.close();
            } 
        catch (SQLException e) {
            e.printStackTrace();
        }
        return person;
    }
    
    public static Person getPerson(int search) {
        Person p = new Person();
        try {
            DB_Connection dbconn = new DB_Connection();
            Connection myconnection = dbconn.Connection();
            String sqlString;

            sqlString = "SELECT * from `record`.`Person` Where Id = '" + search + "'";

            Statement myStatement = myconnection.createStatement();
            ResultSet rs = myStatement.executeQuery(sqlString);
            while (rs.next()) {
                p.setId(Integer.parseInt(rs.getString("Id")));
                p.setFirstName(rs.getString("firstName"));
                p.setSecondName(rs.getString("secondName"));
                p.setBirthday(rs.getString("birthday"));
            }
             myStatement.close();
                myconnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }
    
}
