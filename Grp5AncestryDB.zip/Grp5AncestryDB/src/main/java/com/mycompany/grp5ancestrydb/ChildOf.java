/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.grp5ancestrydb;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Stephanie
 */
public class ChildOf {

    int childId, parrentId;

    public static List<Integer> getParentsID(int search) {
        List<Integer> list = new ArrayList<Integer>();
        try {
            DB_Connection dbconn = new DB_Connection();
            Connection myconnection = dbconn.Connection();
            String sqlString;

            sqlString = "SELECT * from `record`.`childOf` Where childId = '" + search + "'";

            Statement myStatement = myconnection.createStatement();
            ResultSet rs = myStatement.executeQuery(sqlString);
            while (rs.next()) {
                list.add(Integer.parseInt(rs.getString("parrentId")));
                System.out.println(Integer.parseInt(rs.getString("parrentId")));
            }
             myStatement.close();
                myconnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public static List<Integer> getChildsID(int search) {
        List<Integer> list = new ArrayList<Integer>();
        try {
            DB_Connection dbconn = new DB_Connection();
            Connection myconnection = dbconn.Connection();
            String sqlString;

            sqlString = "SELECT * from `record`.`childOf` Where parrentId = '" + search + "'";

            Statement myStatement = myconnection.createStatement();
            ResultSet rs = myStatement.executeQuery(sqlString);
            while (rs.next()) {
                list.add(Integer.parseInt(rs.getString("childId")));
            }
             myStatement.close();
                myconnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

}
