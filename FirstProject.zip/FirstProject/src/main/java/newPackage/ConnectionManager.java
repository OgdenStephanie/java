/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newPackage;
import java.sql.*;
import java.util.*;
/**
 *
 * @author stephanieogden
 */
public class ConnectionManager {
    
    static Connection con;
     static String url;
     
     public static Connection getConnection()
     {
         try {
          String url = "jdbc:odbc:" + "DataSource"; 
          //DataSource=Database Name
          Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
          
          try {
              con = DriverManager.getConnection(url,"username","password"); 
              //SQL Server's username is "userName"
              //Password is password
          }
          catch (SQLException ex) {
              ex.printStackTrace();
          }
         }
         catch(ClassNotFoundException e) {
             System.out.println(e);
         }
          return con;
     }
}
